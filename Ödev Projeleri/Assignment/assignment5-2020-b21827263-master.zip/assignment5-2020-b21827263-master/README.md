# startercode
A starter code for neural networks
